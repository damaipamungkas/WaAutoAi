package com.example.waautoai

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Membuat tata letak sederhana secara dinamis
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 50, 50, 50)
        }

        val titleText = TextView(this).apply {
            text = "WhatsApp AI Auto-Responder"
            textSize = 20f
            setPadding(0, 0, 0, 30)
        }

        val btnPermission = Button(this).apply {
            text = "Aktifkan Izin Akses Notifikasi"
            setOnClickListener {
                // Membuka pengaturan HP agar izin pembacaan notifikasi diaktifkan
                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                startActivity(intent)
            }
        }

        layout.addView(titleText)
        layout.addView(btnPermission)
        setContentView(layout)
    }
}
