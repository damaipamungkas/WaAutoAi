package com.example.waautoai

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class NotificationService : NotificationListenerService() {

    private val apiKey = "AQ.Ab8RN6Imvut7ybTqhatC4JW1xh-7250ME0MEKM144Cx06GjocA" // Ganti dengan API Key Gemini kamu
    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        
        // Memeriksa apakah notifikasi dari WhatsApp / WA Business
        if (packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b") {
            val extras = sbn.notification.extras
            val title = extras.getString(Notification.EXTRA_TITLE) // Nama pengirim
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() // Isi pesan

            if (title != null && text != null && !title.contains("pesan baru")) {
                Log.d("WaAutoAI", "Pesan dari $title: $text")
                
                // Panggil AI untuk buat balasan
                getAiResponse(text) { replyText ->
                    if (replyText != null) {
                        sendWhatsAppReply(sbn, replyText)
                    }
                }
            }
        }
    }

    // Fungsi untuk meminta balasan dari Gemini API secara langsung
    private fun getAiResponse(userMessage: String, callback: (String?) -> Unit) {
        scope.launch {
            try {
                val urlString = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey"
                val url = URL(urlString)
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; utf-8")
                conn.doOutput = true

                val jsonBody = JSONObject().apply {
                    put("contents", org.json.JSONArray().put(
                        JSONObject().put("parts", org.json.JSONArray().put(
                            JSONObject().put("text", "Kamu adalah asisten AI yang membalas chat WhatsApp secara ramah dan singkat. Balas pesan ini: $userMessage")
                        ))
                    ))
                }

                conn.outputStream.use { os ->
                    val input = jsonBody.toString().toByteArray(Charsets.UTF_8)
                    os.write(input, 0, input.size)
                }

                if (conn.responseCode == 200) {
                    val responseStr = conn.inputStream.bufferedReader().use { it.readText() }
                    val jsonResponse = JSONObject(responseStr)
                    val candidates = jsonResponse.getJSONArray("candidates")
                    val content = candidates.getJSONObject(0).getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    val aiText = parts.getJSONObject(0).getString("text").trim()
                    callback(aiText)
                } else {
                    callback(null)
                }
            } catch (e: Exception) {
                Log.e("WaAutoAI", "Error AI: ${e.message}")
                callback(null)
            }
        }
    }

    // Fungsi untuk mengirim balasan otomatis ke notifikasi WhatsApp
    private fun sendWhatsAppReply(sbn: StatusBarNotification, replyText: String) {
        val actions = sbn.notification.actions ?: return
        for (action in actions) {
            if (action.remoteInputs != null) {
                for (remoteInput in action.remoteInputs) {
                    val intent = Intent()
                    val bundle = Bundle().apply {
                        putCharSequence(remoteInput.resultKey, replyText)
                    }
                    RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
                    try {
                        action.actionIntent.send(this, 0, intent)
                        Log.d("WaAutoAI", "Balasan terkirim: $replyText")
                    } catch (e: Exception) {
                        Log.e("WaAutoAI", "Gagal kirim balasan: ${e.message}")
                    }
                    return
                }
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {}
}
